'use client'

import React from 'react'
import { AppProvider, useApp } from '@/context/AppContext'
import Sidebar from '@/components/Sidebar'
import ChatInterface from '@/components/ChatInterface'
import SolicitorPanel from '@/components/SolicitorPanel'
import AccountantPanel from '@/components/AccountantPanel'
import SupplierPanel from '@/components/SupplierPanel'
import EmailPanel from '@/components/EmailPanel'
import AgentStatusPanel from '@/components/AgentStatusPanel'
import { Toaster } from '@/components/ui/toaster'

function MainContent() {
  const { sidebarCollapsed, activePanel } = useApp()

  const renderActivePanel = () => {
    switch (activePanel) {
      case 'solicitor':
        return <SolicitorPanel />
      case 'accountant':
        return <AccountantPanel />
      case 'supplier':
        return <SupplierPanel />
      case 'email':
        return <EmailPanel />
      case 'agents':
        return <AgentStatusPanel />
      default:
        return <ChatInterface />
    }
  }

  return (
    <div 
      className="flex h-screen bg-zinc-950 text-white overflow-hidden"
      style={{
        minWidth: '960px',
        minHeight: '672px',
      }}
    >
      <Sidebar />
      <main className={`flex-1 flex flex-col transition-all duration-300 ${sidebarCollapsed ? 'ml-0' : ''}`}>
        {renderActivePanel()}
      </main>
    </div>
  )
}

export default function Home() {
  return (
    <AppProvider>
      <MainContent />
      <Toaster />
    </AppProvider>
  )
}
