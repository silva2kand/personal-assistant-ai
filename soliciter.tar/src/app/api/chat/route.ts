import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(req: NextRequest) {
  try {
    const { message, model, conversationHistory } = await req.json()

    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 })
    }

    // Create Z-AI instance
    const zai = await ZAI.create()

    // Build messages array
    const systemPrompt = `You are a helpful AI assistant integrated into a professional services management application.
You help users with:
- UK Legal matters and solicitor management
- UK Accounting and tax-related questions
- Supplier tracking and management
- Email management and communication

When appropriate, delegate tasks to specialized agents:
- Legal Agent: For solicitor-related questions, legal documents, and UK law
- Financial Agent: For accounting, tax deadlines, and financial matters
- Supplier Agent: For supplier orders, invoices, and communications
- Email Agent: For email management and communications
- Research Agent: For gathering information and analysis

Always be helpful, professional, and provide accurate information. If you're unsure about legal or financial matters, recommend consulting with a qualified professional.`

    const messages = [
      { role: 'assistant', content: systemPrompt },
      ...(conversationHistory || []).map((msg: { role: string; content: string }) => ({
        role: msg.role === 'agent' ? 'assistant' : msg.role,
        content: msg.content,
      })),
      { role: 'user', content: message },
    ]

    // Get completion
    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: 'disabled' },
    })

    const response = completion.choices[0]?.message?.content

    // Determine if agents should be involved
    const agents = []
    const lowerMessage = message.toLowerCase()

    if (lowerMessage.includes('solicitor') || lowerMessage.includes('legal') || lowerMessage.includes('law') || lowerMessage.includes('contract')) {
      agents.push({
        type: 'legal',
        name: 'Legal Agent',
        contribution: 'I can help coordinate with your solicitor and analyze legal documents. Would you like me to review any specific legal matters?',
      })
    }

    if (lowerMessage.includes('accountant') || lowerMessage.includes('tax') || lowerMessage.includes('financial') || lowerMessage.includes('invoice')) {
      agents.push({
        type: 'financial',
        name: 'Financial Agent',
        contribution: 'I can assist with tax deadlines, financial documents, and accountant coordination. Shall I check your upcoming tax deadlines?',
      })
    }

    if (lowerMessage.includes('supplier') || lowerMessage.includes('order') || lowerMessage.includes('delivery') || lowerMessage.includes('purchase')) {
      agents.push({
        type: 'supplier',
        name: 'Supplier Agent',
        contribution: 'I can track your orders, manage supplier communications, and monitor invoices. Would you like me to check the status of any orders?',
      })
    }

    if (lowerMessage.includes('email') || lowerMessage.includes('mail') || lowerMessage.includes('inbox')) {
      agents.push({
        type: 'email',
        name: 'Email Agent',
        contribution: 'I can help manage your emails, filter important messages, and draft responses. Would you like me to check your inbox?',
      })
    }

    return NextResponse.json({
      response,
      agents,
    })
  } catch (error) {
    console.error('Chat API Error:', error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to process message' },
      { status: 500 }
    )
  }
}
