'use client'

import React, { useState, useRef, useEffect } from 'react'
import { useApp } from '@/context/AppContext'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import {
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Bot,
  User,
  Scale,
  Calculator,
  Truck,
  Mail,
  Search,
  Loader2,
  StopCircle,
} from 'lucide-react'
import MessageBubble from './MessageBubble'
import AgentVisualization from './AgentVisualization'

export default function ChatInterface() {
  const {
    currentConversation,
    createNewConversation,
    addMessage,
    isLoading,
    setIsLoading,
    voiceEnabled,
    setVoiceEnabled,
    isRecording,
    setIsRecording,
    selectedModel,
    agents,
    activePanel,
  } = useApp()

  const [input, setInput] = useState('')
  const [audioPlaying, setAudioPlaying] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [currentConversation?.messages])

  // Send message
  const handleSend = async () => {
    if (!input.trim() || isLoading) return

    const userMessage = input.trim()
    setInput('')

    // Create conversation if needed
    if (!currentConversation) {
      createNewConversation()
      // Wait for state update
      setTimeout(() => sendMessage(userMessage), 100)
      return
    }

    await sendMessage(userMessage)
  }

  const sendMessage = async (content: string) => {
    addMessage({ role: 'user', content })
    setIsLoading(true)

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: content,
          model: selectedModel,
          conversationHistory: currentConversation?.messages.slice(-10) || [],
        }),
      })

      const data = await response.json()

      if (data.response) {
        addMessage({ role: 'assistant', content: data.response })

        // TTS if enabled
        if (voiceEnabled && data.response) {
          await speakText(data.response)
        }
      }

      // Check if agents were involved
      if (data.agents && data.agents.length > 0) {
        data.agents.forEach((agent: { type: string; name: string; contribution: string }) => {
          addMessage({
            role: 'agent',
            content: agent.contribution,
            agentType: agent.type,
            agentName: agent.name,
          })
        })
      }
    } catch (error) {
      console.error('Chat error:', error)
      addMessage({ role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' })
    } finally {
      setIsLoading(false)
    }
  }

  // Voice Recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      audioChunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data)
      }

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' })
        await transcribeAudio(audioBlob)
        stream.getTracks().forEach(track => track.stop())
      }

      mediaRecorder.start()
      setIsRecording(true)
    } catch (error) {
      console.error('Error accessing microphone:', error)
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
    }
  }

  const transcribeAudio = async (audioBlob: Blob) => {
    try {
      const formData = new FormData()
      formData.append('audio', audioBlob)

      const response = await fetch('/api/voice/transcribe', {
        method: 'POST',
        body: formData,
      })

      const data = await response.json()
      if (data.text) {
        setInput(data.text)
      }
    } catch (error) {
      console.error('Transcription error:', error)
    }
  }

  // Text-to-Speech
  const speakText = async (text: string) => {
    try {
      setAudioPlaying(true)
      const response = await fetch('/api/voice/speak', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      })

      if (response.ok) {
        const audioBlob = await response.blob()
        const audio = new Audio(URL.createObjectURL(audioBlob))
        audio.onended = () => setAudioPlaying(false)
        await audio.play()
      }
    } catch (error) {
      console.error('TTS error:', error)
      setAudioPlaying(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault()
      handleSend()
    }
  }

  const getAgentIcon = (type: string) => {
    switch (type) {
      case 'legal': return Scale
      case 'financial': return Calculator
      case 'supplier': return Truck
      case 'email': return Mail
      case 'research': return Search
      default: return Bot
    }
  }

  // Get active agents
  const activeAgents = agents.filter(a => a.status === 'active' || a.status === 'processing')

  return (
    <div className="flex flex-col h-full bg-zinc-950">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <Bot className="w-6 h-6 text-blue-500" />
          <div>
            <h2 className="text-lg font-semibold text-white">
              {activePanel === 'chat' ? 'AI Assistant' : 
               activePanel === 'solicitor' ? 'UK Solicitor Tracking' :
               activePanel === 'accountant' ? 'UK Accountant Tracking' :
               activePanel === 'supplier' ? 'UK Supplier Tracking' :
               activePanel === 'email' ? 'Email Integration' : 'AI Agents'}
            </h2>
            <p className="text-xs text-zinc-500">
              Powered by {selectedModel.toUpperCase()}
            </p>
          </div>
        </div>
        {activeAgents.length > 0 && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-zinc-500">Active Agents:</span>
            {activeAgents.map(agent => {
              const Icon = getAgentIcon(agent.type)
              return (
                <Badge key={agent.id} variant="outline" className="border-blue-500 text-blue-400">
                  <Icon className="w-3 h-3 mr-1" />
                  {agent.name}
                </Badge>
              )
            })}
          </div>
        )}
      </div>

      {/* Messages Area */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        {!currentConversation || currentConversation.messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Bot className="w-16 h-16 text-zinc-700 mb-4" />
            <h3 className="text-xl font-semibold text-zinc-400 mb-2">How can I help you today?</h3>
            <p className="text-zinc-600 max-w-md">
              I can assist with UK legal matters, accounting, supplier tracking, and email management. 
              Just ask or use voice input.
            </p>
            {/* Agent Visualization */}
            <div className="mt-8">
              <AgentVisualization />
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {currentConversation.messages.map((message) => (
              <MessageBubble key={message.id} message={message} />
            ))}
            {isLoading && (
              <div className="flex items-center gap-3 p-4">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-blue-600">
                    <Bot className="w-4 h-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                  <span className="text-zinc-400">Thinking...</span>
                </div>
              </div>
            )}
          </div>
        )}
      </ScrollArea>

      {/* Input Area */}
      <div className="p-4 border-t border-zinc-800">
        <div className="flex items-end gap-2">
          {/* Voice Input Button */}
          <Button
            variant={isRecording ? "destructive" : "outline"}
            size="icon"
            onClick={isRecording ? stopRecording : startRecording}
            className={`shrink-0 ${isRecording ? 'animate-pulse' : ''}`}
          >
            {isRecording ? <StopCircle className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </Button>

          {/* Text Input */}
          <div className="flex-1 relative">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your message... (Ctrl+Enter to send)"
              className="min-h-[44px] max-h-32 resize-none bg-zinc-900 border-zinc-700 text-white placeholder:text-zinc-500 pr-24"
              rows={1}
            />
          </div>

          {/* Voice Output Toggle */}
          <Button
            variant={voiceEnabled ? "default" : "outline"}
            size="icon"
            onClick={() => setVoiceEnabled(!voiceEnabled)}
            className={`shrink-0 ${voiceEnabled ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
          >
            {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </Button>

          {/* Send Button */}
          <Button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="shrink-0 bg-blue-600 hover:bg-blue-700"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>

        {/* Keyboard Shortcuts Hint */}
        <div className="flex items-center justify-center gap-4 mt-2 text-xs text-zinc-600">
          <span>Ctrl+B: Toggle sidebar</span>
          <span>Ctrl+N: New chat</span>
          <span>Ctrl+M: Toggle voice</span>
          <span>Ctrl+Enter: Send</span>
        </div>
      </div>
    </div>
  )
}
