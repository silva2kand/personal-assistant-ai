'use client'

import React, { useState, useEffect } from 'react'
import { useApp, EmailAccount } from '@/context/AppContext'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Mail,
  Plus,
  Search,
  ExternalLink,
  RefreshCw,
  Check,
  X,
  Clock,
  Inbox,
  Send,
  FileText,
  Star,
  Trash2,
} from 'lucide-react'

// Email provider configurations
const emailProviders = [
  { 
    id: 'gmail', 
    name: 'Gmail', 
    icon: '📧',
    loginUrl: 'https://accounts.google.com/signin',
    color: 'bg-red-600',
    borderColor: 'border-red-500',
    textColor: 'text-red-400'
  },
  { 
    id: 'outlook', 
    name: 'Outlook', 
    icon: '📬',
    loginUrl: 'https://outlook.live.com/owa/',
    color: 'bg-blue-600',
    borderColor: 'border-blue-500',
    textColor: 'text-blue-400'
  },
  { 
    id: 'hotmail', 
    name: 'Hotmail', 
    icon: '📬',
    loginUrl: 'https://outlook.live.com/owa/',
    color: 'bg-blue-600',
    borderColor: 'border-blue-500',
    textColor: 'text-blue-400'
  },
  { 
    id: 'live', 
    name: 'Live', 
    icon: '📬',
    loginUrl: 'https://login.live.com/',
    color: 'bg-green-600',
    borderColor: 'border-green-500',
    textColor: 'text-green-400'
  },
  { 
    id: 'microsoft', 
    name: 'Microsoft 365', 
    icon: '🏢',
    loginUrl: 'https://www.office.com/login',
    color: 'bg-purple-600',
    borderColor: 'border-purple-500',
    textColor: 'text-purple-400'
  },
]

export default function EmailPanel() {
  const { emailAccounts, setEmailAccounts, setActivePanel, addMessage, currentConversation, createNewConversation } = useApp()
  const [searchQuery, setSearchQuery] = useState('')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null)
  const [newEmail, setNewEmail] = useState('')

  // Sample emails for display
  const sampleEmails = [
    { id: 1, from: 'solicitor@lawfirm.co.uk', subject: 'Legal Document Review', preview: 'Please find attached the documents for your review...', time: '10:30 AM', unread: true },
    { id: 2, from: 'accounts@supplier.com', subject: 'Invoice #12345', preview: 'Thank you for your order. Please find the invoice attached...', time: '09:15 AM', unread: true },
    { id: 3, from: 'advisor@accountant.co.uk', subject: 'Tax Deadline Reminder', preview: 'This is a reminder that your self-assessment is due...', time: 'Yesterday', unread: false },
  ]

  const fetchEmailAccounts = async () => {
    try {
      const response = await fetch('/api/emails')
      const data = await response.json()
      setEmailAccounts(data.accounts || [])
    } catch (error) {
      console.error('Failed to fetch email accounts:', error)
    }
  }

  useEffect(() => {
    fetchEmailAccounts()
  }, [])

  const openEmailLogin = (provider: typeof emailProviders[0]) => {
    window.open(provider.loginUrl, '_blank')
  }

  const addEmailAccount = async () => {
    if (!selectedProvider || !newEmail) return

    try {
      const response = await fetch('/api/emails', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: selectedProvider,
          email: newEmail,
        }),
      })
      const data = await response.json()
      if (data.account) {
        setEmailAccounts([...emailAccounts, data.account])
        setNewEmail('')
        setSelectedProvider(null)
        setIsAddDialogOpen(false)
      }
    } catch (error) {
      console.error('Failed to add email account:', error)
    }
  }

  const chatAboutEmail = (email: typeof sampleEmails[0]) => {
    if (!currentConversation) {
      createNewConversation()
    }
    setActivePanel('chat')
    setTimeout(() => {
      addMessage({
        role: 'user',
        content: `I received an email from ${email.from} with subject "${email.subject}". Can you help me understand and respond to this?`,
      })
    }, 100)
  }

  const getProvider = (providerId: string) => {
    return emailProviders.find(p => p.id === providerId)
  }

  return (
    <div className="flex flex-col h-full bg-zinc-950">
      {/* Header */}
      <div className="p-4 border-b border-zinc-800">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Mail className="w-6 h-6 text-blue-500" />
            <div>
              <h2 className="text-lg font-semibold text-white">Email Integration</h2>
              <p className="text-xs text-zinc-500">Connect and manage your email accounts</p>
            </div>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Email
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
              <DialogHeader>
                <DialogTitle>Add Email Account</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="grid grid-cols-3 gap-2">
                  {emailProviders.map((provider) => (
                    <Button
                      key={provider.id}
                      variant={selectedProvider === provider.id ? 'default' : 'outline'}
                      className={`h-16 flex-col ${selectedProvider === provider.id ? provider.color : ''}`}
                      onClick={() => setSelectedProvider(provider.id)}
                    >
                      <span className="text-xl">{provider.icon}</span>
                      <span className="text-xs">{provider.name}</span>
                    </Button>
                  ))}
                </div>
                <Input
                  placeholder="Email address"
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="bg-zinc-800 border-zinc-700"
                />
                <div className="flex gap-2">
                  <Button 
                    onClick={addEmailAccount} 
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    disabled={!selectedProvider || !newEmail}
                  >
                    Add Account
                  </Button>
                  {selectedProvider && (
                    <Button
                      variant="outline"
                      onClick={() => openEmailLogin(getProvider(selectedProvider)!)}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Login
                    </Button>
                  )}
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            placeholder="Search emails..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-zinc-900 border-zinc-700"
          />
        </div>
      </div>

      {/* Connected Accounts */}
      <div className="p-4 border-b border-zinc-800 bg-zinc-900/50">
        <div className="flex items-center gap-2 mb-2">
          <Check className="w-4 h-4 text-green-500" />
          <span className="text-sm font-medium text-white">Connected Accounts</span>
        </div>
        {emailAccounts.length === 0 ? (
          <p className="text-xs text-zinc-600">No accounts connected. Add an email account to get started.</p>
        ) : (
          <div className="flex gap-2 flex-wrap">
            {emailAccounts.map((account) => {
              const provider = getProvider(account.provider)
              return (
                <Badge key={account.id} variant="outline" className={`${provider?.borderColor} ${provider?.textColor}`}>
                  {provider?.icon} {account.email}
                </Badge>
              )
            })}
          </div>
        )}
      </div>

      {/* Quick Login Buttons */}
      <div className="p-4 border-b border-zinc-800">
        <p className="text-xs text-zinc-500 mb-2">Quick Login Access</p>
        <div className="grid grid-cols-5 gap-2">
          {emailProviders.map((provider) => (
            <Button
              key={provider.id}
              variant="outline"
              size="sm"
              className="h-12 flex-col text-xs"
              onClick={() => openEmailLogin(provider)}
            >
              <span className="text-base">{provider.icon}</span>
              <span className="mt-0.5">{provider.name}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Recent Emails */}
      <ScrollArea className="flex-1 p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-medium text-white">Recent Emails</span>
          <Button variant="ghost" size="sm">
            <RefreshCw className="w-3 h-3 mr-1" />
            Refresh
          </Button>
        </div>

        <div className="space-y-2">
          {sampleEmails.map((email) => (
            <Card 
              key={email.id} 
              className={`bg-zinc-900 border-zinc-800 hover:border-zinc-700 transition-colors cursor-pointer ${
                email.unread ? 'border-l-2 border-l-blue-500' : ''
              }`}
              onClick={() => chatAboutEmail(email)}
            >
              <CardContent className="p-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      {email.unread && <div className="w-2 h-2 rounded-full bg-blue-500" />}
                      <span className={`text-sm truncate ${email.unread ? 'font-medium text-white' : 'text-zinc-400'}`}>
                        {email.from}
                      </span>
                    </div>
                    <p className={`text-sm truncate ${email.unread ? 'text-white' : 'text-zinc-400'}`}>
                      {email.subject}
                    </p>
                    <p className="text-xs text-zinc-500 truncate">{email.preview}</p>
                  </div>
                  <div className="flex items-center gap-1 shrink-0 ml-2">
                    <span className="text-xs text-zinc-600">{email.time}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Email Actions */}
        <div className="mt-4 flex gap-2">
          <Button variant="outline" size="sm" className="flex-1">
            <Inbox className="w-3 h-3 mr-1" />
            Inbox
          </Button>
          <Button variant="outline" size="sm" className="flex-1">
            <Send className="w-3 h-3 mr-1" />
            Sent
          </Button>
          <Button variant="outline" size="sm" className="flex-1">
            <FileText className="w-3 h-3 mr-1" />
            Drafts
          </Button>
          <Button variant="outline" size="sm" className="flex-1">
            <Star className="w-3 h-3 mr-1" />
            Starred
          </Button>
        </div>
      </ScrollArea>
    </div>
  )
}
