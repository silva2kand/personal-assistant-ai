'use client'

import React from 'react'
import { useApp } from '@/context/AppContext'
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Globe, Server, Check, X, Loader2 } from 'lucide-react'

export default function ModelSelector() {
  const { models, selectedModel, setSelectedModel } = useApp()

  const apiModels = models.filter(m => m.type === 'api')
  const localModels = models.filter(m => m.type === 'local')

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'available':
        return <Check className="w-3 h-3 text-green-500" />
      case 'unavailable':
        return <X className="w-3 h-3 text-red-500" />
      case 'checking':
        return <Loader2 className="w-3 h-3 text-yellow-500 animate-spin" />
      default:
        return null
    }
  }

  return (
    <Select value={selectedModel} onValueChange={setSelectedModel}>
      <SelectTrigger className="w-full bg-zinc-800 border-zinc-700 text-white">
        <SelectValue placeholder="Select model" />
      </SelectTrigger>
      <SelectContent className="bg-zinc-800 border-zinc-700">
        <SelectGroup>
          <SelectLabel className="text-zinc-400 flex items-center gap-2">
            <Globe className="w-3 h-3" />
            API Models
          </SelectLabel>
          {apiModels.map((model) => (
            <SelectItem
              key={model.id}
              value={model.id}
              className="text-white hover:bg-zinc-700 focus:bg-zinc-700"
            >
              <div className="flex items-center justify-between w-full gap-2">
                <span>{model.name}</span>
                <Badge variant="outline" className="text-[10px] border-zinc-600 text-zinc-400">
                  {model.provider}
                </Badge>
              </div>
            </SelectItem>
          ))}
        </SelectGroup>
        <SelectGroup>
          <SelectLabel className="text-zinc-400 flex items-center gap-2">
            <Server className="w-3 h-3" />
            Local Models
          </SelectLabel>
          {localModels.map((model) => (
            <SelectItem
              key={model.id}
              value={model.id}
              disabled={model.status === 'unavailable'}
              className={`text-white hover:bg-zinc-700 focus:bg-zinc-700 ${
                model.status === 'unavailable' ? 'opacity-50' : ''
              }`}
            >
              <div className="flex items-center justify-between w-full gap-2">
                <span>{model.name}</span>
                <div className="flex items-center gap-1">
                  {getStatusIcon(model.status)}
                </div>
              </div>
            </SelectItem>
          ))}
        </SelectGroup>
      </SelectContent>
    </Select>
  )
}
