'use client'

import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react'

// Types
export interface Message {
  id: string
  role: 'user' | 'assistant' | 'system' | 'agent'
  content: string
  agentType?: string
  agentName?: string
  timestamp: Date
}

export interface Conversation {
  id: string
  title: string
  messages: Message[]
  model: string
  createdAt: Date
}

export interface Solicitor {
  id: string
  name: string
  firm: string | null
  email: string | null
  phone: string | null
  specialty: string | null
  status: string
}

export interface Accountant {
  id: string
  name: string
  firm: string | null
  email: string | null
  phone: string | null
  specialty: string | null
  status: string
}

export interface Supplier {
  id: string
  name: string
  category: string | null
  email: string | null
  phone: string | null
  status: string
}

export interface EmailAccount {
  id: string
  provider: string
  email: string
  displayName: string | null
  status: string
}

export interface Agent {
  id: string
  type: 'legal' | 'financial' | 'supplier' | 'email' | 'research'
  name: string
  status: 'idle' | 'active' | 'processing' | 'error'
  description: string
}

export interface Model {
  id: string
  name: string
  provider: string
  type: 'api' | 'local'
  status: 'available' | 'unavailable' | 'checking'
}

// Context Type
interface AppContextType {
  // Sidebar
  sidebarCollapsed: boolean
  toggleSidebar: () => void
  setSidebarCollapsed: (collapsed: boolean) => void
  
  // Model Selection
  selectedModel: string
  setSelectedModel: (model: string) => void
  models: Model[]
  
  // Chat
  conversations: Conversation[]
  currentConversation: Conversation | null
  setCurrentConversation: (conv: Conversation | null) => void
  createNewConversation: () => void
  addMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void
  isLoading: boolean
  setIsLoading: (loading: boolean) => void
  
  // Voice
  voiceEnabled: boolean
  setVoiceEnabled: (enabled: boolean) => void
  isRecording: boolean
  setIsRecording: (recording: boolean) => void
  
  // Professional Services
  solicitors: Solicitor[]
  setSolicitors: (solicitors: Solicitor[]) => void
  accountants: Accountant[]
  setAccountants: (accountants: Accountant[]) => void
  suppliers: Supplier[]
  setSuppliers: (suppliers: Supplier[]) => void
  
  // Email
  emailAccounts: EmailAccount[]
  setEmailAccounts: (accounts: EmailAccount[]) => void
  
  // Agents
  agents: Agent[]
  setAgents: (agents: Agent[]) => void
  activePanel: 'chat' | 'solicitor' | 'accountant' | 'supplier' | 'email' | 'agents'
  setActivePanel: (panel: 'chat' | 'solicitor' | 'accountant' | 'supplier' | 'email' | 'agents') => void
}

const defaultModels: Model[] = [
  // API Models
  { id: 'z-ai', name: 'Z-AI', provider: 'Z-AI', type: 'api', status: 'available' },
  { id: 'gemini', name: 'Gemini Pro', provider: 'Google', type: 'api', status: 'available' },
  { id: 'qwen', name: 'Qwen', provider: 'Alibaba', type: 'api', status: 'available' },
  { id: 'deepseek', name: 'DeepSeek', provider: 'DeepSeek', type: 'api', status: 'available' },
  { id: 'grok', name: 'Grok', provider: 'xAI', type: 'api', status: 'available' },
  { id: 'openai', name: 'GPT-4', provider: 'OpenAI', type: 'api', status: 'available' },
  { id: 'claude', name: 'Claude', provider: 'Anthropic', type: 'api', status: 'available' },
  { id: 'mistral', name: 'Mistral', provider: 'Mistral AI', type: 'api', status: 'available' },
  // Local Models
  { id: 'ollama', name: 'Ollama', provider: 'Local', type: 'local', status: 'checking' },
  { id: 'lmstudio', name: 'LM Studio', provider: 'Local', type: 'local', status: 'checking' },
]

const defaultAgents: Agent[] = [
  { id: 'legal', type: 'legal', name: 'Legal Agent', status: 'idle', description: 'UK Solicitor assistance' },
  { id: 'financial', type: 'financial', name: 'Financial Agent', status: 'idle', description: 'UK Accountant assistance' },
  { id: 'supplier', type: 'supplier', name: 'Supplier Agent', status: 'idle', description: 'Supplier tracking & management' },
  { id: 'email', type: 'email', name: 'Email Agent', status: 'idle', description: 'Email management & monitoring' },
  { id: 'research', type: 'research', name: 'Research Agent', status: 'idle', description: 'Information gathering & analysis' },
]

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: ReactNode }) {
  // Sidebar State
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  
  // Model Selection
  const [selectedModel, setSelectedModel] = useState('z-ai')
  const [models, setModels] = useState<Model[]>(defaultModels)
  
  // Chat State
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  
  // Voice State
  const [voiceEnabled, setVoiceEnabled] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  
  // Professional Services
  const [solicitors, setSolicitors] = useState<Solicitor[]>([])
  const [accountants, setAccountants] = useState<Accountant[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  
  // Email
  const [emailAccounts, setEmailAccounts] = useState<EmailAccount[]>([])
  
  // Agents
  const [agents, setAgents] = useState<Agent[]>(defaultAgents)
  const [activePanel, setActivePanel] = useState<'chat' | 'solicitor' | 'accountant' | 'supplier' | 'email' | 'agents'>('chat')
  
  // Toggle Sidebar
  const toggleSidebar = useCallback(() => {
    setSidebarCollapsed(prev => !prev)
  }, [])
  
  // Create New Conversation
  const createNewConversation = useCallback(() => {
    const newConv: Conversation = {
      id: `conv-${Date.now()}`,
      title: 'New Chat',
      messages: [],
      model: selectedModel,
      createdAt: new Date(),
    }
    setConversations(prev => [newConv, ...prev])
    setCurrentConversation(newConv)
  }, [selectedModel])
  
  // Add Message
  const addMessage = useCallback((message: Omit<Message, 'id' | 'timestamp'>) => {
    const newMessage: Message = {
      ...message,
      id: `msg-${Date.now()}`,
      timestamp: new Date(),
    }
    
    setCurrentConversation(prev => {
      if (!prev) return null
      const updatedConv = {
        ...prev,
        messages: [...prev.messages, newMessage],
        title: prev.messages.length === 0 ? message.content.slice(0, 30) + '...' : prev.title,
      }
      setConversations(convs => convs.map(c => c.id === prev.id ? updatedConv : c))
      return updatedConv
    })
  }, [])
  
  // Check Local Models on Mount
  useEffect(() => {
    const checkLocalModels = async () => {
      try {
        const response = await fetch('/api/models/local')
        const data = await response.json()
        
        setModels(prev => prev.map(model => {
          if (model.id === 'ollama') {
            return { ...model, status: data.ollama ? 'available' : 'unavailable' }
          }
          if (model.id === 'lmstudio') {
            return { ...model, status: data.lmstudio ? 'available' : 'unavailable' }
          }
          return model
        }))
      } catch (error) {
        console.error('Failed to check local models:', error)
        setModels(prev => prev.map(model => 
          model.type === 'local' ? { ...model, status: 'unavailable' } : model
        ))
      }
    }
    
    checkLocalModels()
  }, [])
  
  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key.toLowerCase()) {
          case 'b':
            e.preventDefault()
            toggleSidebar()
            break
          case 'n':
            e.preventDefault()
            createNewConversation()
            break
          case 'm':
            e.preventDefault()
            setVoiceEnabled(prev => !prev)
            break
        }
      }
    }
    
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [toggleSidebar, createNewConversation])
  
  return (
    <AppContext.Provider value={{
      sidebarCollapsed,
      toggleSidebar,
      setSidebarCollapsed,
      selectedModel,
      setSelectedModel,
      models,
      conversations,
      currentConversation,
      setCurrentConversation,
      createNewConversation,
      addMessage,
      isLoading,
      setIsLoading,
      voiceEnabled,
      setVoiceEnabled,
      isRecording,
      setIsRecording,
      solicitors,
      setSolicitors,
      accountants,
      setAccountants,
      suppliers,
      setSuppliers,
      emailAccounts,
      setEmailAccounts,
      agents,
      setAgents,
      activePanel,
      setActivePanel,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider')
  }
  return context
}
